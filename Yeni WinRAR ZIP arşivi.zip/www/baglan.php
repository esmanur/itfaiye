<?php

$baglan=mysqli_connect("localhost","root","","itfaiye"); 
mysqli_query($baglan, "SET NAMES UTF8");







?>

