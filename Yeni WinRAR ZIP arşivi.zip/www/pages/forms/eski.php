<?php
require("baglan.php");
// include,require_once
if(!$baglan){ //bağlanmazsa
	die("Bağlantı Başarısız".mysql_connect_error());
//die eğer bağlantı yapılmadıysa aşağıdaki komutları kesiyo aşağıdaki komutları çalıştırmıyo kullanıcıya yük bindirmiyo boşa çalışmıyo
}
else
{
	echo "Bağlantı Başarılı";
}

$olaytarih=$_POST["yangin_olay_tarih"];
$kayittarih=$_POST["yangin_kayit_tarihi"];
$bildno=$_POST["bildirim_sira_no"];
$bildsaat=$_POST["bildirme_saati"];
$bildalan=$_POST["bildirim_alan"];
$bildadres=$_POST["bildirilen_adres"];
$sokak=$_POST["sokak_id"];
$mahalle=$_POST["mahalle_id"];
$no=$_POST["no"];
$ilce=$_POST["ilce_id"];
$yangintur=$_POST["tur_ad"];
$yanginsinif=$_POST["yangin_sinif_ad"];
$yanginsebep=$_POST["sebep_ad"];
$kisi=$_POST["kisi_id"];
$kiramulk=$_POST["kiraci_mulksahip"];
$amir=$_POST["amir"];
$persay=$_POST["personel_sayi"];
$aracsayi=$_POST["arac_sayi"];
$plaka=$_POST["plaka"];
$cikis=$_POST["cikis_saati"];
$varis=$_POST["varis_saati"];
$durum=$_POST["gorulen_durum"];
$sondurme=$_POST["sondurme_tur_id"];


$sondurucu=$_POST["sondurucu_id"];
$hasar=$_POST["hasar_durum"];
$neden=$_POST["yangin_cikis_neden"];
$donustarih=$_POST["ekip_donus_tarih"];
$donussaat=$_POST["ekip_donus_saat"];



if($olaytarih&$kayittarih&$bildno&$bildsaat&$bildalan&$bildadres&$sokak&$mahalle&$no&$ilce&$yangintur&$yanginsinif&$yanginsebep&$kisi&$kiramulk&$amir&$persay&$aracsayi&$plaka&$cikis&$varis&$amir&$persay&$aracsayi&$plaka&$cikis&$varis&$durum&$sondurme&$sondurucu&$hasar&$neden&$donustarih&$donussaat) {
	$sorgu="insert into yangin(yangin_olay_tarih,yangin_kayit_tarihi,bildirim_sira_no,bildirme_saati,bildirim_alan,bildirilen_adres,sokak_id,mahalle_id,no,ilce_id,tur_ad,yangin_sinif_ad,sebep_ad,kisi_id,kiraci_mulksahip,amir,persone_sayi,arac_sayi,plaka,cikis,varis,amir,persone_sayi,arac_sayi,plaka,cikis,varis,gorulen_durum,sondurme_tur_id,sondurucu_id,hasar_durum,yangin_cikis_neden,ekip_donus_tarih,ekip_donus_saat) values ('$olaytarih','$kayittarih','$bildno','$bildsaat','$bildalan','$bildadres','$sokak','$mahalle','$no','$ilce','$yangintur','$yanginsinif','$yanginsebep','$kisi','$kiramulk','$amir','$persay',$aracsayi','$plaka','$cikis','$varis','$amir','$persay',$aracsayi','plaka','$cikis','$varis','$durum','$sondurme','$sondurucu','$hasar','$neden','$donustarih','$donussaat')";

	if(mysqli_query($baglan,$sorgu)===True) { 
		 	echo"Kayıtlar Başarıyla Eklendi";
		 	header("Refresh: 2; url=index2.php");
		 	
	}
	else{
		 	echo"Kayıtlar eklenemedi";
	}

}
else{
	echo"Lütfen tüm alanları doldurunuz";
   }
?>