<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Yangin KAyıt</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"></script src="<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
</head>
<body>
<div>
<form class="form-signin" action="index2.php" method="POST">
	<h4 class="form-signin-heading">Yangın Kayıt Girişi</h4><br>
	

	Yangın Olay Tarihi:
	<input type="date" name="yangin_olay_tarih" placeholder="Yangın Olay Tarihi" class="form-control"> 

	Yangin Kayıt Tarihi:
	<input type="date" name="yangin_kayit_tarihi" placeholder="Yangın Kayıt Tarihi" class="form-control">

	Bildirim Sıra No:
	<input type="number" name="bildirim_sira_no"  class="form-control"> 

	Bildirme Saati:
	<input type="time" name="bildirme_Saati" class="form-control"> 

	Bildirimi Alan:
	<input type="text" name="bildirim_alan" class="form-control"> 
	<br>

	Bildirilen Adres:
	<textarea name="bildirilen_adres"></textarea>
	<br>
	<br>



	Doğru Adres:

	Sokak:     
    <input type="text" name="amir" placeholder="Sokağı Giriniz: " class="form-control"> 
    Mahalle:
    <input type="text" name="amir" placeholder="Mahalleyi Giriniz: " class="form-control"> 
    İlçe:
    <select name="adres_id">
    <option value="a">A Sınıfı Yangın</option>
    <option value="b">B Sınıfı Yangın</option>
    <option value="c">C Sınıfı Yangın</option>
    <option value="d">D Sınıfı Yangın</option>
    <option value="e">Elektrik Yangınları</option>
    <option value="f">F Sınıfı Yangın</option>
    </select>




	<br>
	<br>
	Yangın Türü:
	<select name="tur_ad">
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    </select>


    Yangın Sınıfı:
    <select name="yangin_sinif_ad">
    <option value="A">A Sınıfı Yangın</option>
    <option value="B">B Sınıfı Yangın</option>
    <option value="C">C Sınıfı Yangın</option>
    <option value="D Sınıfı">D Sınıfı Yangın</option>
    <option value="Elektrik">Elektrik Yangınları</option>
    <option value="F">F Sınıfı Yangın</option>
    </select>

    Yangın Sebebi:
    <select name="yangin_sebep">
    <option value="onlem">Yangınlardan korunma önlemlerinin alınmaması</option>
    <option value="bilgisizlik">Bilgisizlik</option>
    <option value="ihmal">Ihmal ve dikkatsizlik</option>
    <option value="kazalar">Kazalar</option>
    <option value="sıcrama">Sıçrama</option>
    <option value="sabotaj">Sabotaj</option>
    <option value="tabiat">Tabiat Olayları</option>
    </select><br>
    <br>

    Yanan Şeyin
    <input type="text" name="kisi_id" placeholder="Sahibi: " class="form-control"> 
    <input type="text" name="kiraci_mulksahip" placeholder="Kiracı veya Kullanan:" class="form-control"> 
    <br>

    Giden Ekibin
    <input type="text" name="amir" placeholder="Amiri: " class="form-control"> 
    <input type="number" name="personel_sayi" placeholder="Personel Sayısı: " class="form-control"> 
    <input type="number" name="arac_sayi" placeholder="Araç Sayısı:" class="form-control"> 
    <input type="text" name="plaka" placeholder="Aracın Plakası" class="form-control"> 
    Ekibin Çıkış Saati:
    <input type="time" name="cikis_saati"  class="form-control"> 
    Ekibin Varış Saati:
    <input type="time" name="varis_saati"  class="form-control"> 
    <br>

    Yardımcı Ekibin
    <input type="text" name="amir" placeholder="Amiri: " class="form-control"> 
    <input type="number" name="personel_sayi" placeholder="Personel Sayısı " class="form-control"> 
    <input type="number" name="arac_sayi" placeholder="Araç Sayısı:" class="form-control"> 
    <input type="text" name="plaka" placeholder="Aracın Plakası" class="form-control"> 
    Yardımcı Ekibin Çıkış Saati:
    <input type="time" name="cikis_saati"  class="form-control"> 
    Yardımcı Ekibin Varış Saati:
    <input type="time" name="varis_saati"  class="form-control"> 
    <br>
    Olayın Gördüldüğü Durum:
    <input type="text" name="gorulen_durum"  class="form-control"> 
    <br>

    Yangın Söndürme Türü
    <select name="sondurme_tur_id">
    <option value="soğutma">Soğutarak Söndürme</option>
    <option value="hava">Havayı Kesme</option>
    </select>
    <br>
    <br>
    <br>

    Soğutarak Söndürme İse:
    <input name="sogutma" type="radio" value="su" /> Su İle Soğutma
    <input name="sogutma" type="radio" value="dagitma" /> Yanıcı Maddeyi Dağıtma
    <input name="sogutma" type="radio" value="ufleme" /> Kuvvetli Üfleme
    <br>
    
    Havayı Kesme İse:
    <input name="hava" type="radio" value="ortme" /> Örtme
    <input name="hava" type="radio" value="bogma" /> Boğma
    <br>
    <br>
    <br>

    Kullanılan Yangın Söndürücü:
	<select name="sondurucu_id">
    <option value="su">Su içerikli portatif yangın söndürücü</option>
    <option value="kopuk">Köpüklü portatif söndürücü</option>
    <option value="karbon">CO2’li portatif yangın söndürücü</option>
    <option value="kuru">Kuru kimyevi tozlu portatif yangın söndürücü</option>
    </select>
    <br>
    <br>

    Söndürme Sonundaki Hasar Durumu:

    <textarea name="hasar_durum"></textarea>

   <br>
   <br>

    Yangın Çıkış Nedeni:
    <textarea name="yangin_cikis_neden"></textarea>
    <br>
    <br>

    Ekibin Dönüş Tarihi:
	<input type="date" name="ekip_donus_tarih" class="form-control">

	Ekibin Dönüş Saati:
	<input type="time" name="ekip_donus_saat" class="form-control"> 

	<br>


    
   
	<button class="btn btn-lg btn-primary btn-block" type="submit">Kaydet ve İlerle</button>
	<form class="form-signin" action="index2.php" method="POST"> </form>
    

</form>
</div>
</body>
</html>