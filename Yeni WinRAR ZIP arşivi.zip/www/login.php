<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Yangın Takip Sistemi</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"></script src="<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
</head>
<body>
<div class="container">
<form class="form-signin" action="kontrol.php" method="POST">
  <br></br>
  <h4>Lütfen Giriş Yapınız</h4>
  <br></br>

  <input type="email" name="eposta" placeholder="E-Mail Adresiniz" class="form-control">

  <input type="password" name="sifre" placeholder="Şifreniz" class="form-control">


  <a href="#">Şifrenizi Unuttunuz mu?</a>
  <button type="submit" class="btn btn-lg btn-success btn-block">Giriş</button>
   
</form>
</div>
</body>
</html>

